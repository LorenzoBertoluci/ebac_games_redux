declare const toast: { warn(args: any): void }
export { toast }
