require('./register') // must be the first
require('./build.ts')
