/**
 * @type {import("@rtk-query/codegen-openapi").ConfigFile}
 */
module.exports = {
  schemaFile: './fixtures/petstore.yaml',
  apiFile: './fixtures/emptyApi.ts',
  outputFile: './tmp/example.ts',
};
