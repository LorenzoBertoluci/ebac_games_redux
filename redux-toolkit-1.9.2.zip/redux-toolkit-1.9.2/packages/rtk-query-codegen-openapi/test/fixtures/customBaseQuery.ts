export const namedBaseQuery = () => {};

export function anotherNamedBaseQuery() {}

export default namedBaseQuery;
