module.exports = {
  testEnvironment: 'node',
  automock: false,
  // roots: ['v2.0/__tests__'],
  transform: { '\\.ts$': ['ts-jest'] },
};
